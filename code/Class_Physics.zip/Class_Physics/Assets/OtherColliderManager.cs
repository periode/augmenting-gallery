﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OtherColliderManager : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    private void OnTriggerEnter(Collider other)
    {
        other.gameObject.GetComponent<Renderer>().material.color = Color.black;
        other.gameObject.GetComponent<Rigidbody>().isKinematic = true;
    }

    private void OnTriggerExit(Collider other)
    {
            //RGB
        //RED GREEN BLUE
        other.gameObject.GetComponent<Renderer>().material.color = new Color(255/255, 105/255, 180/255);

    }
}
