﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MainManager : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    public void ReceivedTouch(Vector3 position, Quaternion rotation){
        // --------------------
        // THIS IS WHERE YOU WRITE THE CODE WHEN THE USER TOUCHES A BLUE PLANE
        // --------------------
    }

    public void TouchedObject(GameObject obj){
        // --------------------
        // THIS IS WHERE YOU WRITE THE CODE WHEN THE USER TOUCHES AN OBJECT
        // --------------------
    }
}
