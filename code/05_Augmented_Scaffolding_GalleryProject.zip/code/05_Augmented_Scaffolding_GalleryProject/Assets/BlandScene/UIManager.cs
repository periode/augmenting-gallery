﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class UIManager : MonoBehaviour {

	// Use this for initialization
	void Start () {
        //-- this is the line that allows you to load a new scene.
        //-- don't forget to add the `using UnityEngine.SceneManagement;` on line 5 ^^^
        //SceneManager.LoadScene("UnityARKitScene");
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
