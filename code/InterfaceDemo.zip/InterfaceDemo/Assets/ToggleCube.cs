using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ToggleCube : MonoBehaviour
{
	public GameObject myObject;
    // Start is called before the first frame update
    void Start()
    {
       print("hello");
	   myObject.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        print("again");
    }

	public void TurnOnOff()
    {
        // conditional statements (if this then that else this other thing)
		if(myObject.activeSelf == true){
        	   myObject.SetActive(false);
    		}else{
			myObject.SetActive(true);
		}
    }
}
