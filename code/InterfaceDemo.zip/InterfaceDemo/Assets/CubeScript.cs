using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CubeScript : MonoBehaviour
{
    public GameObject theObject;
    public AudioSource theAudioPlayer;
    // Start is called before the first frame update
    void Start()
    {
        // here this allows us to see the value of theObject
        print(theObject);

        // here we call the RandomRotation function, which executes all the instructions inside
        RandomRotation();
    }

    // Update is called once per frame
    void Update()
    {
        //RandomRotation();
    }

    public void RandomRotation()
    {
        // first we pick some random value (float = decimal number / integer = whole number)
        int newRandomRotation = Random.Range(-90, 90);

        // print(newRandomRotation);

        // then we modify the object
        theObject.transform.Rotate(0, 0, newRandomRotation, Space.Self);
    }

    public void PlayTheAudio()
    {
        if(theAudioPlayer.isPlaying)
        {
            theAudioPlayer.Stop();
        } else {
            theAudioPlayer.Play();
        }
    }
}