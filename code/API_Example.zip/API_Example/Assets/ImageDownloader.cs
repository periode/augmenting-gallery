﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

public class ImageDownloader : MonoBehaviour {

    //-- this is the example of an URL of the image we want to download
    public string test_url = "https://www.pookpress.co.uk/wp-content/uploads/2015/05/WalterCrane_BabyOwnAesop__4.jpg";

	// Use this for initialization
	void Start () {
        
	}

    //-- this function is public, so it can be called from other scripts (for example: APIBrowser script, line 64)
    //-- with any url that we want
    public void DownloadImage(string url){
        //-- we need to start a coroutine, because downloading takes some time
        //-- and we don't want to block our whole app while it completes
        StartCoroutine("GetImage", url);
    }

    //-- this is where we define our coroutine
    IEnumerator GetImage(string _url){
        //-- start a download of the given URL
        var www = new WWW(_url);

        //-- wait until the download is done
        yield return www;

        //-- past line 30, we know the download is done
        //-- so we get the image width and height
        int img_width = www.texture.width;
        int img_height = www.texture.height;

        //-- and then we create a new texture with these dimensions
        Texture2D texture = new Texture2D(img_width, img_height, TextureFormat.DXT1, false);

        //-- now that we have an empty texture, we copy the downloaded image inside that texture
        //-- assign the downloaded image to sprite
        www.LoadImageIntoTexture(texture);

        //-- we create a new "primitive" game object
        //-- "primitives" are the objects available in GameObject > 3D Object > ...
        GameObject go = GameObject.CreatePrimitive(PrimitiveType.Quad);

        //-- we give it a slightly random position so that they don't overlap
        go.transform.position = new Vector3(Random.Range(-3.0f, 3.0f), Random.RandomRange(-3.0f, 3.0f), 0.0f);

        //-- we scale it up to make it bigger
        go.transform.localScale = new Vector3(4.0f, 4.0f, 4.0f);

        //-- and finally we access the Renderer component
        //-- inside that component, we get the material
        //-- and we set the main texture of this material to be the texture we just created
        go.GetComponent<Renderer>().material.mainTexture = texture;

        //-- and finally we get rid of the downloaded data!
        www.Dispose();
        www = null;
    }
	
	// Update is called once per frame
	void Update () {
		
	}
}
