﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

public class ImageDownloader : MonoBehaviour {

    //-- this is the example of an URL of the image we want to download
    public string test_url = "https://www.pookpress.co.uk/wp-content/uploads/2015/05/WalterCrane_BabyOwnAesop__4.jpg";

	// Use this for initialization
	void Start () {
        
	}

    //-- this function is public, so it can be called from other scripts (for example: APIBrowser script, line 64)
    //-- with any url that we want
    public void DownloadImage(string url){
        //-- we need to start a coroutine, because downloading takes some time
        //-- and we don't want to block our whole app while it completes
        StartCoroutine("GetImage", url);
    }

    //-- this is where we define our coroutine
    IEnumerator GetImage(string _url){
        //-- start a download of the given URL
        //-- we use UnityWebRequestTexture because we know we want to doanload an image
        UnityWebRequest www = UnityWebRequestTexture.GetTexture(_url);

        //-- wait until the download is done
        yield return www.SendWebRequest();

        //-- first we check if there is an error?
        if(www.isNetworkError){
            Debug.Log("Error: " + www.error);
        }
        //-- if not, we can treat the result
        else
        {
            //-- and then we create a new texture with these dimensions
            Texture theTexture = ((DownloadHandlerTexture)www.downloadHandler).texture;

            //-- we create a new "primitive" game object
            //-- "primitives" are the objects available in GameObject > 3D Object > ...
            GameObject go = GameObject.CreatePrimitive(PrimitiveType.Quad);

            //-- we give it a slightly random position so that they don't overlap
            go.transform.position = new Vector3(Random.Range(-3.0f, 3.0f), Random.Range(-3.0f, 3.0f), 0.0f);

            //-- we scale it up to make it bigger
            go.transform.localScale = new Vector3(4.0f, 4.0f, 4.0f);

            //-- and finally we access the Renderer component
            //-- inside that component, we get the material
            //-- and we set the main texture of this material to be the texture we just created
            go.GetComponent<Renderer>().material.mainTexture = theTexture;

        }

        //-- and finally we get rid of the downloaded data!
        www.Dispose();
        www = null;
    }
	
	// Update is called once per frame
	void Update () {
		
	}
}
