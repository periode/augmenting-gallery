﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;
using SimpleJSON;


public class APIBrowser : MonoBehaviour {

    //-- this is our identification which allow us to access the Europeana API
    string API_key = "df568UN2i";

    string url = "https://www.europeana.eu/api/v2/search.json?query=Bauhaus&reusability=open&media=true";

	// Use this for initialization
	void Start () {
        StartCoroutine(GetData());
	}

    private IEnumerator GetData(){
        //-- we combine our endpoint with our API key to have a full URL
        string full_url = url + "&wskey=" + API_key;

        //-- we create a request to start the download of that url
        UnityWebRequest www = UnityWebRequest.Get(full_url);

        //-- we wait until we get somethings
        yield return www.SendWebRequest();

        //-- first we check if there is an error?
        if (www.isNetworkError)
        {
            Debug.Log("Error: " + www.error);
        }
        //-- if not, we can treat the result
        else
        {
            //-- we check how much data we downloaded
            byte[] result = www.downloadHandler.data;
            Debug.Log("Downloaded: " + result.Length + " bytes");

            //-- we convert that data to a JSON format
            //-- this is possible because (1) we are using SimpleJSON on line 5
            //-- and because we have the SimpleJSON.cs script inside our Plugin folder
            var json = JSON.Parse(www.downloadHandler.text);

            //-- now we can take a look at what the "items" field looks like
            Debug.Log(json["items"].AsArray);

            //-- because it's an array (i.e. a collection of data), we use a loop to go through all of them
            for (int i = 0; i < json["items"].AsArray.Count; i++)
            {

                //-- by manually inspecting the data, we know that
                //-- each of the slots in "items", has another array called "edmPreview"
                //-- and the first slot of "edmPreview" is the URL of an image
                //-- so we save it into our "image_url" variable
                string image_url = json["items"][i]["edmPreview"][0].Value;
                Debug.Log("Found image: " + image_url);

                //-- finally, we find the ImageDownloader script (it's on the same object)
                //-- and we call the DownloadImage function, with the image URL that we found
                //-- so that it creates a quad with the downloaded image!
                GetComponent<ImageDownloader>().DownloadImage(image_url);
            }
        }
    }
	
	// Update is called once per frame
	void Update () {
		
	}
}
