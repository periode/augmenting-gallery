﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CubeManager : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    public void SaySomething(){
        Debug.Log("Something");
    }

    public void SaySomethingElse(){
        Debug.Log("Else");
    }
}
