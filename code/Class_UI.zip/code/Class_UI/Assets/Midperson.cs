﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Midperson : MonoBehaviour {

    public GameObject child;
    public Vector3 pointOfEntry;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    public void GiveBirth(){
        GameObject.Instantiate(child, pointOfEntry, Quaternion.identity);
    }

    public void GrowUp(){
        GameObject.Find("Sphere(Clone)").transform.localScale = new Vector3(3, 3, 3);
    }
}
